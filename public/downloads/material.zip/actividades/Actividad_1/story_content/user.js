function ExecuteScript(strId)
{
  switch (strId)
  {
      case "6GR4UTwg31f":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

